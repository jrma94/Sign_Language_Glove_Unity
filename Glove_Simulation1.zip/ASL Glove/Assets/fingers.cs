﻿using UnityEngine;
using System.Collections;
using System.IO.Ports;
using System;

public class fingers : MonoBehaviour {

    SerialPort s = new SerialPort("COM4", 9600); //Set the port (com4) and the baud rate (9600, is standard on most devices)
    float[] data = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 }; //Need the last values to moves fingers
    float[] offset = { -30, -100, -90, -10, -110, 0, 0, 0, 0, 0, 0 };

    // Use this for initialization
    void Start () {
        print("initializing...");
        s.ReadBufferSize = 9600;
        s.DataBits = 8;
        s.ReadTimeout = 10;
        s.Open(); //Open the Serial Stream.

        
        
    }
	
	// Update is called once per frame
	void Update () {
        string value;
        try
        {
            value = s.ReadLine(); //Read the information
        }catch(TimeoutException e)
        {
            value = "-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1";
        }
        string[] readin = value.Split(','); //values are comma delimited
        bool cont = true;

        try
        {
            for (int i = 0; i < 11; i++) //Check if all values are recieved
            {
                if (readin[i] == "" || readin[i] == "-1")
                    cont = false;
            }
        }catch(IndexOutOfRangeException e)
        {
            cont = false;
        }
        

        if (cont) //only continue if we have all values
        {
            
            data[0] = float.Parse(readin[0]) + offset[0];  //Set new values to last time values for the next loop
            data[1] = float.Parse(readin[1]) + offset[1];
            data[2] = float.Parse(readin[2]) + offset[2];
            data[3] = float.Parse(readin[3]) + offset[3];  //Set new values to last time values for the next loop
            data[4] = float.Parse(readin[4]) + offset[4];
            data[5] = float.Parse(readin[5]) + offset[5];
            data[6] = float.Parse(readin[6]) + offset[6];  //Set new values to last time values for the next loop
            data[7] = float.Parse(readin[7]) + offset[7];
            data[8] = float.Parse(readin[8]) + offset[8];
            data[9] = float.Parse(readin[9]) + offset[9];  //Set new values to last time values for the next loop
            data[10] = float.Parse(readin[10]) + offset[10];

            print(readin[5] + readin[6] + readin[7]);

            var thumb = GameObject.Find("thumb");
            thumb.transform.rotation = Quaternion.Euler(-60, 0, -2 * (data[0] / 4 + 50));
            var index = GameObject.Find("index");
            index.transform.rotation =  Quaternion.Euler(0, 0, -2 * (data[1] / 4 + 50));
            var middle = GameObject.Find("middle");
            middle.transform.rotation = Quaternion.Euler(0, 0, -2 * (data[2] / 4 + 50));
            var ring = GameObject.Find("ring");
            ring.transform.rotation = Quaternion.Euler(0, 0, -2 * (data[3] / 4 + 50));
            var pinky = GameObject.Find("pinky");
            pinky.transform.rotation = Quaternion.Euler(0, 0, -2 * (data[4] / 4 + 50));

            var wrist = GameObject.Find("wrist");
            wrist.transform.rotation = Quaternion.Euler(data[6] * 3, data[5] , data[7] * -3 );


            s.BaseStream.Flush(); //Clear the serial information so we assure we get new information.
        }


        

    }

    void OnGUI()
    {
        string newString = data[0] + "\n" + data[1] + "\n" + data[2] + "\n" + data[3] + "\n" + data[4] + "\n" + data[5] + "\n" + data[6] + "\n" + data[7] + "\n" + data[8] + ", " + data[9] + ", " + data[10];
        GUI.Label(new Rect(10, 10, 100, 200), newString); //Display new values
                                                          // Though, it seems that it outputs the value in percentage O-o I don't know why.
    }
}
